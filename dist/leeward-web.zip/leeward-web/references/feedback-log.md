# Feedback log

The owner's corrections, newest first. Each is a rule with its reason. These override the rest of the skill.

<!-- Format: - YYYY-MM-DD: RULE. Why: REASON. -->

- 2026-11-08: Get the client's logo before choosing colours or fonts, and take the palette and type mood from it (measure the colours). Never invent a palette from the business name. Why: for Hanami I guessed warm paper and a blossom pink from the name; the real logo is pure black and white with a thin geometric sans, and the site had to be restyled.

- 2026-11-08 (Hanami test build, self-found): don't scrape or work around login walls and rate limits on Instagram/Facebook/Google to get a client's photos. Ask the owner to send them. Why: the session's safety checks block it, and the photos need permission anyway.

- 2026-11-08: SEO, speed, security and legal rules are hard launch gates, and they outrank design choices. Why: the owner wants sites that rank, load fast and give nobody grounds to sue.

- 2026-11-08: The hard rules beat reference sites. Learn why a reference works; don't copy its pill buttons or two-button heroes. Why: most of the owner's favourite sites break the owner's own rules.

- 2026-11-07: Sites vary in feel (premium, playful, simple, in-depth). Pick one per project; don't default
  to one house look. Why: Leeward builds for very different clients.
- 2026-11-07: No pill-shaped buttons. Why: owner's taste, reads as template/AI.
- 2026-11-07: Never two buttons in the hero; one or none. Why: one clear action; two compete.
- 2026-11-07: No drastic fonts or colours. Why: personality should come from photos, spacing and copy.

- 2026-11-07: Every Leeward site gets a WhatsApp route to the business, and a prefilled WhatsApp fallback
  when the enquiry form fails. Why: Caribbean guests book over WhatsApp; a lost enquiry is a lost booking.
- 2026-11-07: No prices unless the client explicitly wants them shown; default to "quoted on request".
  Why: Reel Charters quotes every trip.
